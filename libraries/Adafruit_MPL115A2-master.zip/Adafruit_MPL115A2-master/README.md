# Adafruit_MPL115A2 [![Build Status](https://travis-ci.com/adafruit/Adafruit_MPL115A2.svg?branch=master)](https://travis-ci.com/adafruit/Adafruit_MPL115A2)

<a href="https://www.adafruit.com/products/992"><img src="assets/board.jpg?raw=true" width="500px"></a>

Driver for the Adafruit MPL115A2 barometric pressure sensor breakout.

To install, use the Arduino Library Manager and search for 'Adafruit MPL115A2' and install the library.

